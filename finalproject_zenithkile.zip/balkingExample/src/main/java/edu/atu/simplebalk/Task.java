/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package edu.atu.simplebalk;

/**
 *
 * @author zee
 */
public class Task {
    private boolean isReady = false;
    
    public void ready() {
        this.isReady = true;
    }
    
    public void execute() {
        synchronized(this) {
            if (!isReady) {
                System.out.println("Error! Can not execute action!");
                System.out.println("Check if another task is executing"
                        + " or if the system is ready.");
                return;
            }
            else {
                System.out.println("Executing task...");
                this.isReady = false;
                completed();

            }
        }
    }
    
    public void completed() {
        synchronized(this) {
            System.out.println("Task completed successfully!");
            this.isReady = true;
        }
    }
}
