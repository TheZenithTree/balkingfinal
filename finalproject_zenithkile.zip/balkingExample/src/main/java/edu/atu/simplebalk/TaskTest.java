/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.atu.simplebalk;
import java.lang.Runnable;


/**
 *
 * @author zee
 */
public class TaskTest {

    public static void main(String[] args) {
        Task task = new Task();
        
        //Test Thread 1: Failure then Success Thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                //Failure Test in Thread 1
                System.out.println("Attempting failure test in thread 1...");
                task.execute();
                
                try {
                    Thread.sleep(1000);
                }
                catch (InterruptedException IE){
                }
                
                //Success Test in Thread 1
                System.out.println("Attempting success test in thread 1...");
                task.execute();
                
                
            }
        }).start();
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                //Success Test in Thread 2
                System.out.println("Attempting success test in thread 2...");
                task.ready();
                task.execute();
            }
            
        }).start();
                
    }
    
}
