/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

package edu.atu.balkingoriginal;

/**
 *
 * @author zee
 */
public class CarDoor {
    private boolean isLocked = true;
    
    public void unlockDoor()
    {
        this.isLocked = false;
        
        System.out.println("The car door is unlocked!");
    }
    
    public void lockDoor ()
    {
        this.isLocked = true;
        
    }
    
    public void openDoor()
    {
        synchronized(this) {
            if (isLocked == false) {
                System.out.println("Car door opened!");
            }
            else {
                System.out.println("Error! Door is locked. Action not completed...");
                return;
            }
        }
    }
    
    
}
