/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 */

package edu.atu.balkingoriginal;

/**
 *
 * @author zee
 */

import java.lang.Runnable;

public class DoorTest {
    public static void main(String[] args) {
        CarDoor door = new CarDoor();

        
        //Test Thread 1: Failure then Success Thread
        new Thread(new Runnable() {
            @Override
            public void run() {
                //Failure Test in Thread 1
                System.out.println("Attempting failure test in thread 1...");
                door.openDoor();
                
                try {
                    Thread.sleep(1000);
                }
                catch (InterruptedException IE){
                }
                
                //Success Test in Thread 1
                System.out.println("Attempting success test in thread 1...");
                door.openDoor();
                
                
            }
        }).start();
        
        new Thread(new Runnable() {
            @Override
            public void run() {
                //Success Test in Thread 2
                System.out.println("Attempting success test in thread 2...");
                door.unlockDoor();
                door.openDoor();
            }
            
        }).start();
                
    }
}
